package com.blasingame.salestax.receipt;

import com.blasingame.salestax.exceptions.ItemException;
import com.blasingame.salestax.inventory.Item;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class SalesReceiptTest {

    private SalesReceipt systemUnderTest;

    private static final double EXPECTED_REGULAR_PRICE = 11;

    private static final double EXPECTED_EXEMPT_PRICE = 10;

    private static final double EXPECTED_IMPORTED_PRICE = 11.5;

    private static final double EXPECTED_IMPORTED_AND_EXEMPT_PRICE = 10.5;

    private static final double EXPECTED_MULTIPLE_QUANTITY_PRICE = 33;

    private static final String EXPECTED_NULL_ITEM_MESSAGE = "Cannot have empty item.";

    private static final String EXPECTED_ZERO_QUANTITY_ITEM_MESSAGE = "Cannot have zero quantity item.";

    private static final String EXPECTED_ZERO_PRICE_ITEM_MESSAGE = "Cannot have zero price item.";

    @BeforeEach
    private void init() {
        this.systemUnderTest = new SalesReceipt();
    }


    @Test
    public void onCalculateTotalPriceWithRegularItemThenReturnPrice() throws ItemException {
        Item item = createRegularItem();
        double price = systemUnderTest.calculateTotalPrice(item);
        Assertions.assertEquals(EXPECTED_REGULAR_PRICE, price);
    }

    @Test
    public void onCalculateTotalPriceWithExemptItemThenReturnPrice() throws ItemException {
        Item item = createExemptItem();
        double price = systemUnderTest.calculateTotalPrice(item);
        Assertions.assertEquals(EXPECTED_EXEMPT_PRICE, price);
    }

    @Test
    public void onCalculateTotalPriceWithImportedItemThenReturnPrice() throws ItemException {
        Item item = createImportedItem();
        double price = systemUnderTest.calculateTotalPrice(item);
        Assertions.assertEquals(EXPECTED_IMPORTED_PRICE, price);
    }

    @Test
    public void onCalculateTotalPriceWithImportedExemptItemThenReturnPrice() throws ItemException {
        Item item = createImportedAndExemptItem();
        double price = systemUnderTest.calculateTotalPrice(item);
        Assertions.assertEquals(EXPECTED_IMPORTED_AND_EXEMPT_PRICE, price);
    }

    @Test
    public void onCalculateTotalPriceMultipleQuantityItemThenReturnPrice() throws ItemException {
        Item item = createMultipleQuantityRegularItem();
        double price = systemUnderTest.calculateTotalPrice(item);
        Assertions.assertEquals(EXPECTED_MULTIPLE_QUANTITY_PRICE, price);
    }

    @Test
    public void onCalculateTotalPriceWithNullItemThenThrowException() {
        try {
            double price = systemUnderTest.calculateTotalPrice(null);
            Assertions.fail();
        } catch (ItemException e) {
            Assertions.assertEquals(EXPECTED_NULL_ITEM_MESSAGE, e.getMessage());
        }
    }

    @Test
    public void onCalculateTotalPriceWithZeroQuantityThenThrowException() throws ItemException {
        try {
            Item item = createZeroQuantityRegularItem();
            double price = systemUnderTest.calculateTotalPrice(item);
            Assertions.fail();
        } catch (ItemException e) {
            Assertions.assertEquals(EXPECTED_ZERO_QUANTITY_ITEM_MESSAGE, e.getMessage());
        }
    }

    @Test
    public void onCalculateTotalPriceWithZeroPriceThenReturnPrice() {
        try {
            Item item = createZeroPriceRegularItem();
            double price = systemUnderTest.calculateTotalPrice(item);
            Assertions.fail();
        } catch (ItemException e) {
            Assertions.assertEquals(EXPECTED_ZERO_PRICE_ITEM_MESSAGE, e.getMessage());
        }
    }

    private Item createRegularItem() throws ItemException {
        Item item = new Item(1, "Something", 10, false, false);
        return item;
    }

    private Item createExemptItem() throws ItemException {
        Item item = new Item(1, "Something", 10, true, false);
        return item;
    }

    private Item createImportedItem() throws ItemException {
        Item item = new Item(1, "Something", 10, false, true);
        return item;
    }

    private Item createImportedAndExemptItem() throws ItemException {
        Item item = new Item(1, "Something", 10, true, true);
        return item;
    }

    private Item createMultipleQuantityRegularItem() throws ItemException {
        Item item = new Item(3, "Something", 10, false, false);
        return item;
    }

    private Item createZeroQuantityRegularItem() throws ItemException {
        Item item = new Item(0, "Something", 10, false, false);
        return item;
    }

    private Item createZeroPriceRegularItem() throws ItemException {
        Item item = new Item(1, "Something", 0, false, false);
        return item;
    }
}
