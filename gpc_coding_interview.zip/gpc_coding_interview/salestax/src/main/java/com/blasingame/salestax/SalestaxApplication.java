package com.blasingame.salestax;

import com.blasingame.salestax.exceptions.ItemException;
import com.blasingame.salestax.inventory.Item;
import com.blasingame.salestax.receipt.SalesReceipt;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class SalestaxApplication {

    public static void main(String[] args) throws ItemException, IOException {

        String exitCase = "end";
        List<Item> shoppingCart = new ArrayList<>();

        try (Scanner scanner = new Scanner(new File("src/main/resources/Test-Sales-Tax-Input.txt"))) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                if (line.startsWith("##")) {
                    continue;
                }
                if (line.equals(exitCase)) {
                    SalesReceipt salesReceipt = new SalesReceipt();
                    salesReceipt.printReceipt(shoppingCart);
                    shoppingCart.clear();
                } else {
                    String[] splitArr = line.split(",");
                    int itemQuantity = Integer.parseInt(splitArr[0]);
                    String itemName = splitArr[1];
                    double price = Double.parseDouble(splitArr[2]);
                    boolean isExempt = Boolean.parseBoolean(splitArr[3]);
                    boolean isImported = Boolean.parseBoolean(splitArr[4]);
                    Item item = new Item(itemQuantity, itemName, price, isExempt, isImported);
                    shoppingCart.add(item);
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }
}
