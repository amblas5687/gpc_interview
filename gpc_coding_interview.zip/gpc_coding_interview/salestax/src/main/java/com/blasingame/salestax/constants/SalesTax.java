package com.blasingame.salestax.constants;

public class SalesTax {

    private SalesTax() {
    }

    private static double SALES_TAX = .10;

    private static double IMPORT_TAX = .05;

    public static double getSalesTax() {
        return SALES_TAX;
    }

    public static double getImportTax() {
        return IMPORT_TAX;
    }
}
