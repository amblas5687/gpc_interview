package com.blasingame.salestax.inventory;

import com.blasingame.salestax.exceptions.ItemException;

public class Item {

    private int itemQuantity;

    private String itemName;

    private double price;

    private boolean isExempt;

    private boolean isImported;

    public Item(int itemQuantity, String itemName, double price, boolean isExempt, boolean isImported) throws ItemException {
        this.itemQuantity = itemQuantity;
        this.itemName = itemName;
        this.price = price;
        this.isExempt = isExempt;
        this.isImported = isImported;

        if (this.itemQuantity == 0) {
            throw new ItemException("Cannot have zero quantity item.");
        }

        if (this.price == 0) {
            throw new ItemException("Cannot have zero price item.");
        }
    }

    public int getItemQuantity() {
        return itemQuantity;
    }

    public void setItemQuantity(int itemQuantity) throws ItemException {
        this.itemQuantity = itemQuantity;
        if (this.itemQuantity == 0) {
            throw new ItemException("Cannot have zero quantity item.");
        }
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) throws ItemException {
        this.price = price;
        if (this.price == 0) {
            throw new ItemException("Cannot have zero price item.");
        }
    }

    public boolean isExempt() {
        return isExempt;
    }

    public void setExempt(boolean exempt) {
        isExempt = exempt;
    }

    public boolean isImported() {
        return isImported;
    }

    public void setImported(boolean imported) {
        isImported = imported;
    }
}
