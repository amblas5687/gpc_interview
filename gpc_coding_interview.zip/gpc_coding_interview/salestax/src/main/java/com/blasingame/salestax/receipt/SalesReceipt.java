package com.blasingame.salestax.receipt;

import com.blasingame.salestax.constants.SalesTax;
import com.blasingame.salestax.exceptions.ItemException;
import com.blasingame.salestax.inventory.Item;

import java.text.DecimalFormat;
import java.util.List;


public class SalesReceipt {

    private DecimalFormat df;

    private double totalSalesPrice;

    private double totalSalesTax;

    public SalesReceipt() {
        this.totalSalesTax = 0;
        this.totalSalesPrice = 0;
        this.df = new DecimalFormat("0.00");
    }

    private double calculateSalesTax(double price) {
        double itemSalesTax = (price * SalesTax.getSalesTax());
        double roundedSalesTax = roundTax(itemSalesTax);
        this.totalSalesTax += roundedSalesTax;
        return roundedSalesTax;
    }

    private double calculateImportTax(double price) {
        double itemImportTax = (price * SalesTax.getImportTax());
        double roundedImportTax = roundTax(itemImportTax);
        this.totalSalesTax += roundedImportTax;
        return roundedImportTax;
    }

    private static double roundTax(double tax) {
        return Math.ceil(tax * 20) / 20.0;
    }

    public double calculateTotalPrice(Item item) throws ItemException {
        if (item == null) {
            throw new ItemException("Cannot have empty item.");
        }
        double totalPrice;
        if (!item.isExempt() && !item.isImported()) {
            double itemSalesTax = calculateSalesTax(item.getPrice());
            totalPrice = item.getPrice() + itemSalesTax;
        } else if (!item.isExempt() && item.isImported()) {
            double importedSalesTax = calculateImportTax(item.getPrice());
            double itemSalesTax = calculateSalesTax(item.getPrice());
            totalPrice = item.getPrice() + importedSalesTax + itemSalesTax;
        } else if (item.isExempt() && item.isImported()) {
            double importedSalesTax = calculateImportTax(item.getPrice());
            totalPrice = item.getPrice() + importedSalesTax;
        } else {
            totalPrice = item.getPrice();
        }
        this.totalSalesPrice += totalPrice;
        return totalPrice * item.getItemQuantity();
    }

    public void printReceipt(List<Item> itemList) throws ItemException {
        StringBuilder outputReceipt = new StringBuilder();
        System.out.println("*******************************************");
        System.out.println("Printing Shopping Receipt");
        for (Item item : itemList) {
            double itemPriceWithTax = calculateTotalPrice(item);
            outputReceipt.append(item.getItemQuantity()).append(" ").append(item.getItemName()).append(": ").append(df.format(itemPriceWithTax));
            outputReceipt.append("\n");
        }
        outputReceipt.append("Sales Taxes: ").append(df.format(this.totalSalesTax)).append("\n").append("Total: ").append(df.format(this.totalSalesPrice));
        System.out.println(outputReceipt.toString());
        System.out.println("*******************************************");
    }

    public double getTotalSalesPrice() {
        return totalSalesPrice;
    }

    public double getTotalSalesTax() {
        return totalSalesTax;
    }
}
