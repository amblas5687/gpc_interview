package com.blasingame.salestax.exceptions;

public class ItemException extends Exception {

    public ItemException(String message) {
        super(message);
    }
}
